﻿namespace EP01_Ecommerce_API.DTOs
{
    public class CarritoCreateDTO
    {
    }
}
