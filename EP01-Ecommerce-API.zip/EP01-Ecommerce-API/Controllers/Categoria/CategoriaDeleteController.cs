﻿namespace EP01_Ecommerce_API.Controllers.Categoria
{
    public class CategoriaDeleteController
    {
    }
}
