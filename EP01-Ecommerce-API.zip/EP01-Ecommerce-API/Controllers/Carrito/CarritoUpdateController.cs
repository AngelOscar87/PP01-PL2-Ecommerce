﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EP01_Ecommerce_API.Models;
using System.Threading.Tasks;

namespace EP01_Ecommerce_API.Controllers.Carritos
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarritoUpdateController : ControllerBase
    {
        private readonly EcommerceContext _context;

        public CarritoUpdateController(EcommerceContext context)
        {
            _context = context;
        }

        // PUT: api/Carritos/5
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCarrito(int id, Carrito carrito)
        {
            if (id != carrito.CarritoID)
            {
                return BadRequest();
            }

            _context.Entry(carrito).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CarritoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        private bool CarritoExists(int id)
        {
            return _context.Carritos.Any(e => e.CarritoID == id);
        }
    }
}
