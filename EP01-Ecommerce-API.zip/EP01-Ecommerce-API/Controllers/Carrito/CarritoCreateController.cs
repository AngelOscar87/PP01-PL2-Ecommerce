﻿using Microsoft.AspNetCore.Mvc;
using EP01_Ecommerce_API.Models;
using System.Threading.Tasks;

namespace EP01_Ecommerce_API.Controllers.Carritos
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarritoCreateController : ControllerBase
    {
        private readonly EcommerceContext _context;

        public CarritoCreateController(EcommerceContext context)
        {
            _context = context;
        }

        // POST: api/Carritos
        [HttpPost]
        public async Task<ActionResult<Carrito>> CreateCarrito(Carrito carrito)
        {
            _context.Carritos.Add(carrito);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetCarrito", new { id = carrito.CarritoID }, carrito);
        }
    }
}
