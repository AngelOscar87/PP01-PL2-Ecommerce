﻿using Microsoft.AspNetCore.Mvc;
using EP01_Ecommerce_API.Models;
using System.Threading.Tasks;

namespace EP01_Ecommerce_API.Controllers.Carritos
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarritoDeleteController : ControllerBase
    {
        private readonly EcommerceContext _context;

        public CarritoDeleteController(EcommerceContext context)
        {
            _context = context;
        }

        // DELETE: api/Carritos/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCarrito(int id)
        {
            var carrito = await _context.Carritos.FindAsync(id);
            if (carrito == null)
            {
                return NotFound();
            }

            _context.Carritos.Remove(carrito);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
