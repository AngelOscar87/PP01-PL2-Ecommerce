﻿using Microsoft.AspNetCore.Mvc;
using EP01_Ecommerce_API.Models;
using System.Threading.Tasks;

namespace EP01_Ecommerce_API.Controllers.Productos
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductoCreateController : ControllerBase
    {
        private readonly EcommerceContext _context;

        public ProductoCreateController(EcommerceContext context)
        {
            _context = context;
        }

        // POST: api/Productos
        [HttpPost]
        public async Task<ActionResult<Producto>> CreateProducto(Producto producto)
        {
            _context.Productos.Add(producto);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetProducto", new { id = producto.ProductoID }, producto);
        }
    }
}
