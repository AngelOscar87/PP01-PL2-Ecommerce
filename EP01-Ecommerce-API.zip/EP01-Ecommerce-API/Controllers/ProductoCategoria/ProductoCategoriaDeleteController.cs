﻿namespace EP01_Ecommerce_API.Controllers.ProductoCategoria
{
    public class ProductoCategoriaDeleteController
    {
    }
}
