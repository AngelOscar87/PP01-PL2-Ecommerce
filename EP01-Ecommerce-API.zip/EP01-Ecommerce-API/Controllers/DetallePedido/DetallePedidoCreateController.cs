﻿using Microsoft.AspNetCore.Mvc;
using EP01_Ecommerce_API.Models;
using System.Threading.Tasks;

namespace EP01_Ecommerce_API.Controllers.DetallePedidos
{
    [Route("api/[controller]")]
    [ApiController]
    public class DetallePedidoCreateController : ControllerBase
    {
        private readonly EcommerceContext _context;

        public DetallePedidoCreateController(EcommerceContext context)
        {
            _context = context;
        }

        // POST: api/DetallePedidos
        [HttpPost]
        public async Task<ActionResult<DetallePedido>> CreateDetallePedido(DetallePedido detallePedido)
        {
            _context.DetallePedidos.Add(detallePedido);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetDetallePedido", new { id = detallePedido.DetallePedidoID }, detallePedido);
        }
    }
}
