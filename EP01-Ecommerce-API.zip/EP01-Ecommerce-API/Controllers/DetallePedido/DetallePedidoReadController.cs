﻿using Microsoft.AspNetCore.Mvc;
using EP01_Ecommerce_API.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace EP01_Ecommerce_API.Controllers.DetallePedidos
{
    [Route("api/[controller]")]
    [ApiController]
    public class DetallePedidoReadController : ControllerBase
    {
        private readonly EcommerceContext _context;

        public DetallePedidoReadController(EcommerceContext context)
        {
            _context = context;
        }

        // GET: api/DetallePedidos
        [HttpGet]
        public async Task<ActionResult<IEnumerable<DetallePedido>>> GetDetallePedidos()
        {
            return await _context.DetallePedidos.ToListAsync();
        }

        // GET: api/DetallePedidos/5
        [HttpGet("{id}")]
        public async Task<ActionResult<DetallePedido>> GetDetallePedido(int id)
        {
            var detallePedido = await _context.DetallePedidos.FindAsync(id);

            if (detallePedido == null)
            {
                return NotFound();
            }

            return detallePedido;
        }
    }
}
