﻿using Microsoft.AspNetCore.Mvc;
using EP01_Ecommerce_API.Models;
using System.Threading.Tasks;

namespace EP01_Ecommerce_API.Controllers.DetallePedidos
{
    [Route("api/[controller]")]
    [ApiController]
    public class DetallePedidoDeleteController : ControllerBase
    {
        private readonly EcommerceContext _context;

        public DetallePedidoDeleteController(EcommerceContext context)
        {
            _context = context;
        }

        // DELETE: api/DetallePedidos/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDetallePedido(int id)
        {
            var detallePedido = await _context.DetallePedidos.FindAsync(id);
            if (detallePedido == null)
            {
                return NotFound();
            }

            _context.DetallePedidos.Remove(detallePedido);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
