﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EP01_Ecommerce_API.Models;
using System.Threading.Tasks;

namespace EP01_Ecommerce_API.Controllers.Pedidos
{
    [Route("api/[controller]")]
    [ApiController]
    public class PedidoUpdateController : ControllerBase
    {
        private readonly EcommerceContext _context;

        public PedidoUpdateController(EcommerceContext context)
        {
            _context = context;
        }

        // PUT: api/Pedidos/5
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatePedido(int id, Pedido pedido)
        {
            if (id != pedido.PedidoID)
            {
                return BadRequest();
            }

            _context.Entry(pedido).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PedidoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        private bool PedidoExists(int id)
        {
            return _context.Pedidos.Any(e => e.PedidoID == id);
        }
    }
}
