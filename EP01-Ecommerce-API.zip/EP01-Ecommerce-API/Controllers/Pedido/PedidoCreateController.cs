﻿using Microsoft.AspNetCore.Mvc;
using EP01_Ecommerce_API.Models;
using System.Threading.Tasks;

namespace EP01_Ecommerce_API.Controllers.Pedidos
{
    [Route("api/[controller]")]
    [ApiController]
    public class PedidoCreateController : ControllerBase
    {
        private readonly EcommerceContext _context;

        public PedidoCreateController(EcommerceContext context)
        {
            _context = context;
        }

        // POST: api/Pedidos
        [HttpPost]
        public async Task<ActionResult<Pedido>> CreatePedido(Pedido pedido)
        {
            _context.Pedidos.Add(pedido);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetPedido", new { id = pedido.PedidoID }, pedido);
        }
    }
}
