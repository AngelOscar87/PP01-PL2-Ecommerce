﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EP01_Ecommerce_API.Models;
using System.Threading.Tasks;

namespace EP01_Ecommerce_API.Controllers.Direcciones
{
    [Route("api/[controller]")]
    [ApiController]
    public class DireccionUpdateController : ControllerBase
    {
        private readonly EcommerceContext _context;

        public DireccionUpdateController(EcommerceContext context)
        {
            _context = context;
        }

        // PUT: api/Direcciones/5
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateDireccion(int id, Direccion direccion)
        {
            if (id != direccion.DireccionID)
            {
                return BadRequest();
            }

            _context.Entry(direccion).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DireccionExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        private bool DireccionExists(int id)
        {
            return _context.Direcciones.Any(e => e.DireccionID == id);
        }
    }
}
