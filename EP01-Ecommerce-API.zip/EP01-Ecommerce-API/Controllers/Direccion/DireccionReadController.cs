﻿using Microsoft.AspNetCore.Mvc;
using EP01_Ecommerce_API.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace EP01_Ecommerce_API.Controllers.Direcciones
{
    [Route("api/[controller]")]
    [ApiController]
    public class DireccionReadController : ControllerBase
    {
        private readonly EcommerceContext _context;

        public DireccionReadController(EcommerceContext context)
        {
            _context = context;
        }

        // GET: api/Direcciones
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Direccion>>> GetDirecciones()
        {
            return await _context.Direcciones.ToListAsync();
        }

        // GET: api/Direcciones/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Direccion>> GetDireccion(int id)
        {
            var direccion = await _context.Direcciones.FindAsync(id);

            if (direccion == null)
            {
                return NotFound();
            }

            return direccion;
        }
    }
}
