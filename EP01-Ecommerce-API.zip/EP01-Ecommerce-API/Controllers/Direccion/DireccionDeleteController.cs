﻿using Microsoft.AspNetCore.Mvc;
using EP01_Ecommerce_API.Models;
using System.Threading.Tasks;

namespace EP01_Ecommerce_API.Controllers.Direcciones
{
    [Route("api/[controller]")]
    [ApiController]
    public class DireccionDeleteController : ControllerBase
    {
        private readonly EcommerceContext _context;

        public DireccionDeleteController(EcommerceContext context)
        {
            _context = context;
        }

        // DELETE: api/Direcciones/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDireccion(int id)
        {
            var direccion = await _context.Direcciones.FindAsync(id);
            if (direccion == null)
            {
                return NotFound();
            }

            _context.Direcciones.Remove(direccion);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
