﻿using Microsoft.AspNetCore.Mvc;
using EP01_Ecommerce_API.Models;
using System.Threading.Tasks;

namespace EP01_Ecommerce_API.Controllers.Direcciones
{
    [Route("api/[controller]")]
    [ApiController]
    public class DireccionCreateController : ControllerBase
    {
        private readonly EcommerceContext _context;

        public DireccionCreateController(EcommerceContext context)
        {
            _context = context;
        }

        // POST: api/Direcciones
        [HttpPost]
        public async Task<ActionResult<Direccion>> CreateDireccion(Direccion direccion)
        {
            _context.Direcciones.Add(direccion);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetDireccion", new { id = direccion.DireccionID }, direccion);
        }
    }
}
