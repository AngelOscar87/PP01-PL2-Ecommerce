﻿using Microsoft.AspNetCore.Mvc;
using EP01_Ecommerce_API.Models;
using System.Threading.Tasks;

namespace EP01_Ecommerce_API.Controllers.Pagos
{
    [Route("api/[controller]")]
    [ApiController]
    public class PagoCreateController : ControllerBase
    {
        private readonly EcommerceContext _context;

        public PagoCreateController(EcommerceContext context)
        {
            _context = context;
        }

        // POST: api/Pagos
        [HttpPost]
        public async Task<ActionResult<Pago>> CreatePago(Pago pago)
        {
            _context.Pagos.Add(pago);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetPago", new { id = pago.PagoID }, pago);
        }
    }
}
