﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EP01_Ecommerce_API.Models;
using System.Threading.Tasks;

namespace EP01_Ecommerce_API.Controllers.Pagos
{
    [Route("api/[controller]")]
    [ApiController]
    public class PagoUpdateController : ControllerBase
    {
        private readonly EcommerceContext _context;

        public PagoUpdateController(EcommerceContext context)
        {
            _context = context;
        }

        // PUT: api/Pagos/5
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatePago(int id, Pago pago)
        {
            if (id != pago.PagoID)
            {
                return BadRequest();
            }

            _context.Entry(pago).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PagoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        private bool PagoExists(int id)
        {
            return _context.Pagos.Any(e => e.PagoID == id);
        }
    }
}
