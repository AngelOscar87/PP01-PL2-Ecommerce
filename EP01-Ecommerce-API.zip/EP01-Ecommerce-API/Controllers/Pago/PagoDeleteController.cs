﻿namespace EP01_Ecommerce_API.Controllers.Pago
{
    public class PagoDeleteController
    {
    }
}
