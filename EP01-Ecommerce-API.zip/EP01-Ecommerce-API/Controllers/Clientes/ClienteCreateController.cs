﻿using Microsoft.AspNetCore.Mvc;
using EP01_Ecommerce_API.Models;
using System.Threading.Tasks;

namespace EP01_Ecommerce_API.Controllers.Clientes
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClienteCreateController : ControllerBase
    {
        private readonly EcommerceContext _context;

        public ClienteCreateController(EcommerceContext context)
        {
            _context = context;
        }

        // POST: api/Clientes
        [HttpPost]
        public async Task<ActionResult<Cliente>> CreateCliente(Cliente cliente)
        {
            _context.Clientes.Add(cliente);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetCliente", new { id = cliente.ClienteID }, cliente);
        }
    }
}
