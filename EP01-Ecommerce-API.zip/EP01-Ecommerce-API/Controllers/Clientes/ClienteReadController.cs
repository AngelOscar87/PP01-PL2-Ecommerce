﻿using Microsoft.AspNetCore.Mvc;
using EP01_Ecommerce_API.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace EP01_Ecommerce_API.Controllers.Clientes
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClienteReadController : ControllerBase
    {
        private readonly EcommerceContext _context;

        public ClienteReadController(EcommerceContext context)
        {
            _context = context;
        }

        // GET: api/Clientes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Cliente>>> GetClientes()
        {
            return await _context.Clientes.ToListAsync();
        }

        // GET: api/Clientes/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Cliente>> GetCliente(int id)
        {
            var cliente = await _context.Clientes.FindAsync(id);

            if (cliente == null)
            {
                return NotFound();
            }

            return cliente;
        }
    }
}
