﻿using System;

namespace EP01_Ecommerce_API.Models
{
    public class Carrito
    {
        public int CarritoID { get; set; }
        public int ClienteID { get; set; }
        public DateTime FechaCreacion { get; set; }

        public Cliente Cliente { get; set; }
    }
}
