﻿namespace EP01_Ecommerce_API.Models
{
    public class ProductoCategoria
    {
        public int ProductoID { get; set; }
        public Producto Producto { get; set; }

        public int CategoriaID { get; set; }
        public Categoria Categoria { get; set; }
    }
}
