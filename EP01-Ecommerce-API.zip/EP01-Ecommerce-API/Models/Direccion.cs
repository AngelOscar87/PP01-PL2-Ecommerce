﻿namespace EP01_Ecommerce_API.Models
{
    public class Direccion
    {
        public int DireccionID { get; set; }
        public int ClienteID { get; set; }
        public string Calle { get; set; }
        public string Ciudad { get; set; }
        public string Estado { get; set; }
        public string CodigoPostal { get; set; }

        public Cliente Cliente { get; set; }
    }
}
