﻿using System;

namespace EP01_Ecommerce_API.Models
{
    public class Pago
    {
        public int PagoID { get; set; }
        public int PedidoID { get; set; }
        public decimal Monto { get; set; }
        public DateTime FechaPago { get; set; }
        public string MetodoPago { get; set; }

        public Pedido Pedido { get; set; }
    }
}
