﻿using System.Collections.Generic;

namespace EP01_Ecommerce_API.Models
{
    public class Cliente
    {
        public int ClienteID { get; set; }
        public string Nombre { get; set; }
        public string Correo { get; set; }
        public string Telefono { get; set; }

        public ICollection<Direccion> Direcciones { get; set; }
        public ICollection<Carrito> Carritos { get; set; }
        public ICollection<Pedido> Pedidos { get; set; }
    }
}
