﻿using System;
using System.Collections.Generic;

namespace EP01_Ecommerce_API.Models
{
    public class Pedido
    {
        public int PedidoID { get; set; }
        public int ClienteID { get; set; }
        public DateTime FechaPedido { get; set; }
        public decimal Total { get; set; }

        public Cliente Cliente { get; set; }
        public ICollection<DetallePedido> DetallePedidos { get; set; }
        public Pago Pago { get; set; }
    }
}
