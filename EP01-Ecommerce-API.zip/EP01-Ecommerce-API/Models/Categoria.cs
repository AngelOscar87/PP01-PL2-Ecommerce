﻿using System.Collections.Generic;

namespace EP01_Ecommerce_API.Models
{
    public class Categoria
    {
        public int CategoriaID { get; set; }
        public string Nombre { get; set; }

        public ICollection<ProductoCategoria> ProductoCategorias { get; set; }
    }
}
