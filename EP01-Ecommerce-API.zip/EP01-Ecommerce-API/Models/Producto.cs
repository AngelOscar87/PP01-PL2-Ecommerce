﻿using System.Collections.Generic;

namespace EP01_Ecommerce_API.Models
{
    public class Producto
    {
        public int ProductoID { get; set; }
        public string Nombre { get; set; }
        public decimal Precio { get; set; }
        public string Descripcion { get; set; }

        public ICollection<ProductoCategoria> ProductoCategorias { get; set; }
        public ICollection<DetallePedido> DetallePedidos { get; set; }
    }
}
